package com.example.renaissance;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {


    private TextView welcome_to;
    private TextView Renaissance;
    private Button sign_up_using_google;
    private Button sign_up_using_email;
    private Button Already_a_user_Login;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();

        welcome_to =findViewById(R.id.welcome_to);
        Renaissance =findViewById(R.id.Renaissance);
        sign_up_using_google =findViewById(R.id.sign_up_using_google);
        sign_up_using_email =findViewById(R.id.sign_up_using_email);
        Already_a_user_Login =findViewById(R.id.Already_a_user_Login);


        welcome_to.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }

        });

       Renaissance.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

           }
       });

       sign_up_using_google.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

       sign_up_using_email.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

           }
       });

       Already_a_user_Login.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

           }
       });




    }
}